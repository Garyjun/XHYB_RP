package com.brainsoon.bsrcm.search.job;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.brainsoon.bsrcm.common.support.LuceneHelper;
import com.brainsoon.bsrcm.search.client.DocumentSearchClient;
import com.brainsoon.bsrcm.search.client.util.DateUtil;
import com.brainsoon.bsrcm.search.client.util.FileUtils;
import com.channelsoft.appframe.common.BaseObject;
import com.channelsoft.appframe.utils.BeanFactoryUtil;

public class DocumentIndexJob extends BaseObject {
	private static String indexFlag = "/indexFlag.txt"; 
	
	public void doIndexJob() {
		try {
			String lastIndexTime = FileUtils.getFileContent(indexFlag);		
			Date lastIndexDate = new Date(0);
			if (StringUtils.isNotBlank(lastIndexTime))
				lastIndexDate = DateUtil.parseTime(lastIndexTime, "yyyyMMddHHmmssSSS");		
			String currentIndexTime = DateUtil.getDateTime(new Date(), "yyyyMMddHHmmssSSS");			
			FileUtils.writeFile(indexFlag, currentIndexTime, false);
			
			logger.debug("��ʼ������[" + lastIndexTime + "]��[" + currentIndexTime + "]���ĵ�����");
			List<String> filePaths = LuceneHelper.loadIncrementResFilePath(lastIndexDate);
			logger.debug("filePaths=========" + filePaths);
			for(String filePath : filePaths) {
				getDocumentSearchClient().createIndex(filePath);
			}
		} catch(IOException e) {
			logger.error("������ʶ�ļ���ȡ�쳣��", e);
		} catch(ParseException e) {
			//������
		}
	}
	
	private DocumentSearchClient getDocumentSearchClient() {
		return (DocumentSearchClient) BeanFactoryUtil.getBean("documentSearchClient");
	}
}
