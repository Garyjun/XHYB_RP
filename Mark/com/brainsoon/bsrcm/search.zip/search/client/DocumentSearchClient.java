package com.brainsoon.bsrcm.search.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.request.AbstractUpdateRequest;
import org.apache.solr.client.solrj.request.ContentStreamUpdateRequest;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.dom4j.DocumentException;

import com.brainsoon.bsrcm.search.client.util.FileUtils;
import com.brainsoon.bsrcm.search.client.util.XmlParser;
import com.channelsoft.appframe.utils.WebappConfigUtil;

/**
 * <dl>
 * <dt>DocumentSearchClient</dt>
 * <dd>Description:���ĵ������ͻ���</dd>
 * <dd>Copyright: Copyright (c) 2011 ���ƿƼ����޹�˾</dd>
 * <dd>Company: ���ƿƼ����޹�˾</dd>
 * <dd>CreateDate: Oct 28, 2011</dd>
 * </dl>
 * 
 * @author ����
 */

public class DocumentSearchClient {
    private static Logger logger = Logger.getLogger(DocumentSearchClient.class
		  .getName());
  
    private final static Map<String, String> fieldNameTable = new HashMap<String, String>();
  
    private static String solrUrl;     
    
	private static class DocumentSearchClientHolder {
		static DocumentSearchClient instance = new DocumentSearchClient();
	}

	public static DocumentSearchClient buildSingleton() {
		return DocumentSearchClientHolder.instance;
	}
	
	public void setSolrUrl(String solrUrl) {
		DocumentSearchClient.solrUrl = solrUrl;
	}
	
	public static String getSolrUrl() {
		return solrUrl;
	}
		
    public void initialize() {
	    solrUrl = WebappConfigUtil.getParameter("solrUrl");
	    
    	fieldNameTable.put("docId", "id");
	    fieldNameTable.put("bookName", "title");
	    fieldNameTable.put("author", "author");
	    fieldNameTable.put("publishingHouse", "category");
	    fieldNameTable.put("type", "subject");
	    fieldNameTable.put("resType", "links");
	    fieldNameTable.put("content", "ikmaxword");	 
	    fieldNameTable.put("all", "");	
    }
    
    public void createIndex(String filePath) {
    	File file = new File(filePath);
    	if(file.isDirectory())
    	   createMultiFileIndex(filePath);
    	else
    	   createSingleFileIndex(filePath);
    }
    
    public void createMultiFileIndex(String docPath) {
	    List<String> docFiles = FileUtils.getFileListBySubfix(docPath, "pdf");  
	    for(String docFile : docFiles) {
	    	createSingleFileIndex(docFile);
	    }
    }
	
    public void createSingleFileIndex(String docFile) {
//	    String docFileName = FileUtils.getFileName(docFile, ".pdf");
	    String docConfigFile = docFile + ".xml";			  
	    try {
		    org.dom4j.Document doc = XmlParser.loadFile(new FileInputStream(new File(docConfigFile)));			
		    DocumentConfig docConfig = new DocumentConfig(doc);
		    if(docConfig == null)
		       return;				 
		    String docId = docConfig.getResPk();  
		    String bookName = docConfig.getBookName();
		    String author = docConfig.getAuthor();
		    String resType = docConfig.getResType();
		    String type = docConfig.getType();
		    String publishingHouse = docConfig.getPublishingHouse();
		    try {
			  createIndex(docFile, docId, bookName, author, type
					    , resType, publishingHouse);
			  logger.info("���������ɹ����ļ���[" + docFile + "]");
		    } catch (SearchException e) {
			  logger.error("��������ʧ�ܣ��ļ���[" + docFile + "]���쳣[" + e.getMessage() + "]");
		    }				 
	    } catch (FileNotFoundException e) {
		    logger.error("�ĵ������ļ�[" + docConfigFile + "]��ʧ��");
	    } catch (DocumentException e) {
		    logger.error("�ĵ������ļ�[" + docConfigFile +"]��ȡ����");
	    }
    }
    
    private void createIndex(String docFile, String docId, String bookName, String author, String type
		    , String resType, String publishingHouse) throws SearchException {	  			    
        SolrServer solr;
		try {
			solr = new CommonsHttpSolrServer(solrUrl);
		} catch (MalformedURLException e) {
			throw new SearchException("���������쳣����ַ���������쳣[" + e.getMessage() + "]");
		}
    
        ContentStreamUpdateRequest up = new ContentStreamUpdateRequest("/update/extract");	      
    
	    try {
			up.addFile(new File(docFile));
		} catch (IOException e) {
			throw new SearchException("���������쳣���ļ���ȡ�쳣���쳣[" + e.getMessage() + "]");
		}
	    
	    up.setParam("literal.id", docId);
	    up.setParam("literal.title", bookName);
	    up.setParam("literal.author", author);
	    up.setParam("literal.category", publishingHouse);
	    up.setParam("literal.subject", String.valueOf(type));	    
	    up.setParam("literal.links", String.valueOf(resType));
	    up.setParam("fmap.content", "ikmaxword");
	    
	    up.setAction(AbstractUpdateRequest.ACTION.COMMIT, true, true);
	    
	    try {
			solr.request(up);
		} catch (SolrServerException e) {
			throw new SearchException("���������쳣�����������쳣���쳣[" + e.getMessage() + "]");
		} catch (IOException e) {
			throw new SearchException("���������쳣��ͨѶ�쳣���쳣[" + e.getMessage() + "]");
		}	
    }	
	  
    public SearchResult query(String content, String field, int start, int maxrow) throws SearchException {	
    	if (StringUtils.isBlank(content) 
    			|| StringUtils.isBlank(field))
    		return null;
    		
	    SolrServer server;
		try {
			server = new CommonsHttpSolrServer(solrUrl);
		} catch (MalformedURLException e) {
			throw new SearchException("�����쳣����ַ���������쳣[" + e.getMessage() + "]");
		}
	    
		SolrQuery query = new SolrQuery();

		String solrFieldName = getSolrFieldName(field);
		if(StringUtils.isNotBlank(solrFieldName))
		   content = solrFieldName + ":" + content;		
		
		String hlField = "*";
		if(!field.equals("all"))
			hlField = getSolrFieldName(field);
		
		query.setQuery(content);			
		query.setHighlight(true);
		query.setParam("fl", "id,title,author,category,subject,links");
		query.setParam("hl.fl", hlField);
		query.setParam("start", String.valueOf(start));
		query.setParam("rows", String.valueOf(maxrow));		
		
		QueryResponse res;
		try {
			res = server.query(query);
		} catch (SolrServerException e) {
			throw new SearchException("�����쳣�����������쳣���쳣[" + e.getMessage() + "]");
		}
		
		SearchResult searchResult = parseQueryResponse(res);

        return searchResult;
    }
	
    private SearchResult parseQueryResponse(QueryResponse res) {
		SolrDocumentList docList = res.getResults();
		long totleRow = docList.getNumFound();
		long startRow = docList.getStart();
        long maxRow = docList.size(); 
		
        SearchResult searchResult = new SearchResult();
        searchResult.setTotleRow(totleRow);
        searchResult.setStartRow(startRow);
        searchResult.setMaxRow(maxRow);
        
        Map<String,Map<String,List<String>>> highlightings = res.getHighlighting();
        
        for(SolrDocument solrDoc : docList)
        {
        	 Document doc = new Document();
        	 //solrDoc.get����ֵ������String�����п�����List
        	 String id = (String)solrDoc.get("id");	        	 
        	 List<String> docNames = (List<String>)solrDoc.get("title");
        	 List<String> authors = (List<String>)solrDoc.get("author");
        	 List<String> publishingHouses = (List<String>)solrDoc.get("category");
        	 List<String> types = (List<String>)solrDoc.get("subject");
        	 List<String> resTypes = (List<String>)solrDoc.get("links");
        	 Map<String,List<String>> matchList =  highlightings.get(id);
        	 
        	 if(matchList == null)
        		continue;
        	 
        	 String docName = "";
        	 String author = "";
        	 String publishingHouse = "";
        	 String type = "";
        	 String resType = "";
        	 if(docNames != null && docNames.size() > 0) {
        		docName =  docNames.get(0);              
        		if(docNames.size() > 1)
        		   docName =  docNames.get(1);  
        		if(matchList.containsKey("title"))
        		   docName =  matchList.get("title").get(0);
        	 }
        			        	 
        	 if(authors != null && authors.size() > 0) {
        		author =  authors.get(0);
        		if(authors.size() > 1)
        		   author =  authors.get(1);
        		if(matchList.containsKey("author"))
        		   author =  matchList.get("author").get(0);	
        	 }
        		
        	 if(publishingHouses != null && publishingHouses.size() > 0) {
        		publishingHouse = publishingHouses.get(0);
        		if(publishingHouses.size() > 1)
        		   publishingHouse = publishingHouses.get(1);
        		if(matchList.containsKey("category"))
        		   publishingHouse =  matchList.get("category").get(0);	
        	 }
        		
        	 if(types != null && types.size() > 0) {
        		type =  types.get(0);
        		if(types.size() > 1)
        		   type =  types.get(1); 
        	 }
        		
        	 if(resTypes != null && resTypes.size() > 0) {
        		 resType =  resTypes.get(0);
        		 if(resTypes.size() > 1)
        			resType =  resTypes.get(1);  
        	 }                  		         	 
        	  
        	 doc.setId(id);
        	 doc.setDocName(docName);
        	 doc.setAuthor(author);	
        	 doc.setPublishingHouse(publishingHouse);
        	 doc.setType(type);
        	 doc.setResType(resType);        	 
        	       	 
        	 List<String> matchContents = new ArrayList<String>();
        	 if(matchList.containsKey("ikmaxword"))
        		 matchContents.addAll(matchList.get("ikmaxword")); 
        	 
        	 doc.addMatchContents(matchContents);   
        	 
        	 searchResult.addDocument(doc);
         }
         return searchResult;
    }
    
    private String getSolrFieldName(String localName) {
    	return fieldNameTable.get(localName);
    }
    
    public static void main(String[] args) {		  
	    try {	      
	      DocumentSearchClient d = DocumentSearchClient.buildSingleton();
	      d.initialize();
	      d.setSolrUrl("http://10.130.29.21:8080/solr");
	      //d.createMultiFileIndex("E:\\ͼ��\\upload");
	      String field = "publishingHouse";
	      String content = "�廪������";
	      int start = 0;
	      int totle = 1;
	      SearchResult sr = d.query(content, field, start, totle);
	      
	      List<Document> lds = sr.getDocuments();	      
	      for(Document doc : lds) {
	    	  System.out.println(doc.getPublishingHouse());
	      }	      
	    } catch (Exception ex) {
	      System.out.println(ex.toString());
	    }
    }
}
