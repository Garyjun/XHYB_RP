package com.brainsoon.bsrcm.search.client;

public class SearchException extends Exception {
	public SearchException(String msg)
	{
		super(msg);
	}
}
